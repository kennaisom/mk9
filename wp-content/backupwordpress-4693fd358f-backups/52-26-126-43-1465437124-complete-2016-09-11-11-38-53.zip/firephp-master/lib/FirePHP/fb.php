<?php

require_once(dirname(__FILE__) . '/Init.php');

FirePHP__autoload('FirePHPCore_fb');
